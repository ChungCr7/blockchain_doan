export const ipfsToHttp = (uri) =>
  uri.replace("ipfs://", "https://ipfs.io/ipfs/");
