import { useEffect, useState, useCallback } from "react";
import Web3 from "web3";
import ABI from "../contract/NFTMarketplaceABI.json";
import { CONTRACT_ADDRESS } from "../constants/contract";
import { uploadFileToIPFS, uploadJSONToIPFS } from "../utils/pinata";

const MAX_FILE_SIZE_MB = 100;

const useMarketplace = () => {
  const [account, setAccount] = useState("");
  const [contract, setContract] = useState(null);
  const [form, setForm] = useState({
    name: "",
    description: "",
    mediaFile: null,
    mediaType: "",
    price: "",
  });
  const [listedNFTs, setListedNFTs] = useState([]);

  // Kết nối ví và smart contract
  useEffect(() => {
    const init = async () => {
      try {
        if (!window.ethereum) return alert("Cần cài đặt MetaMask!");
        const web3 = new Web3(window.ethereum);
        await window.ethereum.request({ method: "eth_requestAccounts" });
        const accounts = await web3.eth.getAccounts();
        const instance = new web3.eth.Contract(ABI, CONTRACT_ADDRESS);

        setAccount(accounts[0]);
        setContract(instance);
      } catch (err) {
        console.error("❌ Không thể kết nối MetaMask:", err);
      }
    };
    init();
  }, []);

  // Xử lý file
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (file.size / 1024 / 1024 > MAX_FILE_SIZE_MB) {
      alert("❌ File vượt quá 100MB.");
      return;
    }

    const fileType = file.type.split("/")[0];
    setForm((prev) => ({
      ...prev,
      mediaFile: file,
      mediaType: fileType,
    }));
  };

  // Tạo và tự động list NFT
  const createNFT = async () => {
    const { name, description, price, mediaFile, mediaType } = form;

    if (!contract || !account) return alert("⚠️ Cần kết nối ví.");
    if (!name || !description || !mediaFile || !mediaType)
      return alert("⚠️ Điền đầy đủ thông tin.");

    try {
      const mediaURI = await uploadFileToIPFS(mediaFile);
      const metadata = { name, description, mediaURI, type: mediaType };
      const tokenURI = await uploadJSONToIPFS(metadata);

      const tx = await contract.methods
        .createNFT(tokenURI, name, description, mediaURI)
        .send({ from: account });

      const tokenId = tx.events?.NFTCreated?.returnValues?.tokenId;

      if (price && parseFloat(price) > 0 && tokenId) {
        const web3 = new Web3(window.ethereum);
        const weiPrice = web3.utils.toWei(price.toString(), "ether");
        await contract.methods.listNFT(tokenId, weiPrice).send({ from: account });
        alert("✅ Tạo và niêm yết thành công!");
      } else {
        alert("✅ NFT tạo thành công!");
      }

      setForm({
        name: "",
        description: "",
        mediaFile: null,
        mediaType: "",
        price: "",
      });

      fetchListings();
    } catch (err) {
      console.error("❌ Lỗi khi tạo NFT:", err);
      alert("❌ Giao dịch thất bại.");
    }
  };

  // Đăng bán NFT
  const listNFT = async (tokenId, price) => {
    try {
      const web3 = new Web3(window.ethereum);
      const weiPrice = web3.utils.toWei(price.toString(), "ether");
      const owner = await contract.methods.ownerOf(tokenId).call();
      if (owner.toLowerCase() !== account.toLowerCase()) {
        return alert("❌ Bạn không phải là chủ sở hữu NFT.");
      }

      await contract.methods.listNFT(tokenId, weiPrice).send({ from: account });
      alert("✅ NFT đã được đăng bán!");
      fetchListings();
    } catch (err) {
      console.error("❌ Lỗi khi list:", err);
      alert("❌ Không thể đăng bán NFT.");
    }
  };

  // Mua NFT
  const buyNFT = async (tokenId) => {
    try {
      const listing = await contract.methods.listings(tokenId).call();
      const price = listing.price;
      const seller = listing.seller;

      if (seller.toLowerCase() === account.toLowerCase()) {
        return alert("⚠️ Không thể mua NFT của chính bạn.");
      }

      await contract.methods.buyNFT(tokenId).send({
        from: account,
        value: price,
      });

      alert("🎉 Mua thành công!");
      fetchListings();
    } catch (err) {
      console.error("❌ Lỗi khi mua NFT:", err);
      alert("❌ Giao dịch mua thất bại.");
    }
  };

  // Metadata
  const getTokenMetadata = useCallback(
    async (tokenId) => {
      try {
        const uri = await contract.methods.tokenURI(tokenId).call();
        const url = uri.replace("ipfs://", "https://ipfs.io/ipfs/");
        const res = await fetch(url);
        const data = await res.json();

        return {
          name: data.name,
          description: data.description,
          media: data.mediaURI?.replace("ipfs://", "https://ipfs.io/ipfs/"),
          type: data.type,
        };
      } catch (err) {
        return {
          name: "Không rõ",
          description: "",
          media: "",
          type: "image",
        };
      }
    },
    [contract]
  );

  // Fetch NFTs đang được niêm yết
  const fetchListings = useCallback(async () => {
    if (!contract) return;

    try {
      const data = await contract.methods.getActiveListings().call();
      const result = [];

      for (const item of data) {
        const meta = await getTokenMetadata(item.tokenId);
        result.push({
          ...item,
          name: meta.name,
          description: meta.description,
          media: meta.media,
          type: meta.type,
        });
      }

      setListedNFTs(result);
    } catch (err) {
      console.error("❌ Không thể lấy danh sách NFT:", err);
    }
  }, [contract, getTokenMetadata]);

  useEffect(() => {
    if (contract) fetchListings();
  }, [contract, fetchListings]);

  return {
    account,
    contract,
    form,
    listedNFTs,
    setForm,
    handleFileChange,
    createNFT,
    listNFT,
    buyNFT,
  };
};

export default useMarketplace;
