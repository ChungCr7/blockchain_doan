import React, { useEffect, useState } from "react";
import Web3 from "web3";
import { useNavigate } from "react-router-dom";
import { ipfsToHttp } from "../utils/ipfs";

const ProductPage = ({ contract, account, buyNFT }) => {
  const [listedNFTs, setListedNFTs] = useState([]);
  const navigate = useNavigate();

  // ✅ Hàm fetch NFT đang được list trên contract
  const fetchListedNFTs = async () => {
    if (!contract) return;
    try {
      const total = await contract.methods.totalSupply().call();
      const temp = [];

      for (let i = 1; i <= total; i++) {
        const listing = await contract.methods.listings(i).call();

        if (listing.isListed) {
          const tokenURI = await contract.methods.tokenURI(i).call();
          const metadataUrl = tokenURI.replace("ipfs://", "https://ipfs.io/ipfs/");
          const res = await fetch(metadataUrl);
          const metadata = await res.json();

          temp.push({
            tokenId: i,
            price: listing.price,
            seller: listing.seller,
            name: metadata.name || "Không tên",
            description: metadata.description || "",
            media: metadata.mediaURI,
            type: metadata.type || "image",
          });
        }
      }

      setListedNFTs(temp);
    } catch (error) {
      console.error("❌ Lỗi khi fetch NFT:", error);
    }
  };

  // ✅ Gọi fetch mỗi lần load trang
  useEffect(() => {
    fetchListedNFTs();
  }, [contract]);

  const renderMedia = (type, mediaUrl, tokenId) => {
    const src = ipfsToHttp(mediaUrl);

    switch (type) {
      case "image":
        return (
          <img
            src={src}
            alt={`NFT ${tokenId}`}
            className="w-full h-36 object-cover rounded mb-2"
          />
        );
      case "audio":
        return (
          <audio controls className="w-full mb-2">
            <source src={src} type="audio/mpeg" />
            Trình duyệt không hỗ trợ audio.
          </audio>
        );
      case "video":
        return (
          <video controls className="w-full h-36 rounded mb-2 object-cover">
            <source src={src} type="video/mp4" />
            Trình duyệt không hỗ trợ video.
          </video>
        );
      default:
        return (
          <div className="w-full h-36 bg-gray-700 rounded flex items-center justify-center text-sm text-gray-400 mb-2">
            📁 Không hỗ trợ xem trước
          </div>
        );
    }
  };

  const handleBuy = async (item) => {
    if (!account) {
      alert("⚠️ Vui lòng kết nối ví trước khi mua NFT.");
      return;
    }

    if (item.seller?.toLowerCase() === account.toLowerCase()) {
      alert("⚠️ Bạn không thể mua NFT của chính mình.");
      return;
    }

    try {
      await buyNFT(item.tokenId, item.price);
      alert("✅ Giao dịch mua thành công!");
      fetchListedNFTs(); // Cập nhật lại sau khi mua
    } catch (err) {
      console.error("❌ Giao dịch mua thất bại:", err);
    }
  };

  return (
    <div className="text-white p-6">
      <h2 className="text-xl font-semibold mb-4">🛍️ Danh sách NFT đang bán</h2>

      {listedNFTs.length === 0 ? (
        <p className="text-gray-400">😔 Chưa có NFT nào được niêm yết.</p>
      ) : (
        <div className="flex flex-wrap gap-4">
          {listedNFTs.map((item) => (
            <div
              key={item.tokenId}
              className="bg-gray-800 text-white p-4 rounded-xl w-60 shadow"
            >
              {renderMedia(item.type, item.media, item.tokenId)}

              <p><b>🌸 Tên:</b> {item.name}</p>
              <p><b>💰 Giá:</b> {Web3.utils.fromWei(item.price.toString(), "ether")} ETH</p>
              <p><b>👤 Bán bởi:</b> {item.seller.slice(0, 6)}...{item.seller.slice(-4)}</p>

              <div className="mt-2 flex gap-2">
                <button
                  onClick={() => handleBuy(item)}
                  className="bg-yellow-400 text-black px-3 py-1 rounded hover:bg-yellow-500 text-sm"
                >
                  🛒 Mua NFT
                </button>
                <button
                  onClick={() => navigate(`/products/${item.tokenId}`)}
                  className="bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600 text-sm"
                >
                  🔍 Xem chi tiết
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ProductPage;
