import React, { useEffect, useState } from "react";
import Web3 from "web3";
import { ipfsToHttp } from "../utils/media";

const TransactionHistoryPage = ({ contract }) => {
  const [transactions, setTransactions] = useState([]);

  useEffect(() => {
    const fetchHistory = async () => {
      if (!contract || !window.ethereum) return;

      try {
        const web3 = new Web3(window.ethereum);
        const events = await contract.getPastEvents("NFTSale", {
          fromBlock: 0,
          toBlock: "latest",
        });

        const mapped = await Promise.all(
          events.map(async (event) => {
            const { tokenId, buyer, price } = event.returnValues;

            const tokenURI = await contract.methods.tokenURI(tokenId).call();
            const listing = await contract.methods.listings(tokenId).call();
            const res = await fetch(ipfsToHttp(tokenURI));
            const meta = await res.json();

            const block = await web3.eth.getBlock(event.blockNumber);
            const time = new Date(block.timestamp * 1000).toLocaleString();

            return {
              tokenId,
              name: meta.name,
              description: meta.description,
              media: ipfsToHttp(meta.mediaURI),
              type: meta.type || "image",
              price: Web3.utils.fromWei(price, "ether") + " ETH",
              buyer,
              seller: listing.seller,
              time,
            };
          })
        );

        setTransactions(mapped.reverse());
      } catch (err) {
        console.error("❌ Lỗi khi lấy lịch sử giao dịch:", err);
      }
    };

    fetchHistory();
  }, [contract]);

  return (
    <div className="text-white max-w-6xl mx-auto px-4 py-10">
      <h2 className="text-2xl font-bold mb-6 text-center">📜 Lịch sử giao dịch NFT</h2>

      {transactions.length === 0 ? (
        <p className="text-center text-gray-400">Chưa có giao dịch nào.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {transactions.map((tx, index) => (
            <div key={index} className="bg-gray-800 p-4 rounded-xl shadow-md hover:bg-gray-700 transition">
              {tx.type === "image" && (
                <img src={tx.media} alt={tx.name} className="w-full h-40 object-cover rounded mb-3" />
              )}
              {tx.type === "audio" && (
                <audio controls className="w-full mb-3">
                  <source src={tx.media} type="audio/mpeg" />
                </audio>
              )}
              {tx.type === "video" && (
                <video controls className="w-full h-40 object-cover rounded mb-3">
                  <source src={tx.media} type="video/mp4" />
                </video>
              )}

              <h3 className="text-lg font-semibold">{tx.name}</h3>
              <p className="text-sm text-gray-400">{tx.description}</p>

              <div className="text-sm mt-3 space-y-1">
                <p>💰 <strong>Giá:</strong> {tx.price}</p>
                <p>👤 <strong>Người bán:</strong> <span className="break-all">{tx.seller}</span></p>
                <p>🛒 <strong>Người mua:</strong> <span className="break-all">{tx.buyer}</span></p>
                <p className="text-gray-400">🕒 {tx.time}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default TransactionHistoryPage;
