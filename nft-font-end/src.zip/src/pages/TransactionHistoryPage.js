import React, { useEffect, useState } from "react";
import { ipfsToHttp } from "../utils/media";

const TransactionHistoryPage = ({ account, contract }) => {
  const [ownedNFTs, setOwnedNFTs] = useState([]);
  const [createdNFTs, setCreatedNFTs] = useState([]);

  useEffect(() => {
    if (!account || !contract) return;

    const fetchHistory = async () => {
      const owned = [];
      const created = [];
      const total = await contract.methods.totalSupply().call();

      for (let i = 1; i <= total; i++) {
        try {
          const owner = await contract.methods.ownerOf(i).call();
          const listing = await contract.methods.listings(i).call();
          const tokenURI = await contract.methods.tokenURI(i).call();

          const res = await fetch(ipfsToHttp(tokenURI));
          const meta = await res.json();

          const item = {
            tokenId: i,
            name: meta.name,
            description: meta.description,
            media: meta.mediaURI,
            type: meta.type,
            seller: listing.seller,
          };

          if (owner.toLowerCase() === account.toLowerCase()) {
            owned.push(item);
          }

          if (listing.seller.toLowerCase() === account.toLowerCase()) {
            created.push(item);
          }
        } catch (err) {
          console.error("❌ Lỗi tokenId", i, err);
        }
      }

      setOwnedNFTs(owned);
      setCreatedNFTs(created);
    };

    fetchHistory();
  }, [account, contract]);

  const renderCard = (nft) => (
    <div key={nft.tokenId} className="bg-gray-800 p-4 rounded-xl">
      {nft.type === "image" && (
        <img
          src={ipfsToHttp(nft.media)}
          alt={nft.name}
          className="w-full h-40 object-cover rounded mb-2"
        />
      )}
      {nft.type === "audio" && (
        <audio controls className="w-full mb-2">
          <source src={ipfsToHttp(nft.media)} type="audio/mpeg" />
        </audio>
      )}
      {nft.type === "video" && (
        <video controls className="w-full h-40 rounded mb-2 object-cover">
          <source src={ipfsToHttp(nft.media)} type="video/mp4" />
        </video>
      )}
      <p className="font-bold">{nft.name}</p>
      <p className="text-sm text-gray-400">{nft.description}</p>
    </div>
  );

  return (
    <div className="text-white p-6 max-w-5xl mx-auto">
      <h2 className="text-2xl font-bold mb-6 text-center">📜 Lịch sử giao dịch</h2>

      <div className="mb-10">
        <h3 className="text-xl font-semibold mb-3">🎁 NFT bạn đã mua</h3>
        {ownedNFTs.length === 0 ? (
          <p className="text-gray-400">Bạn chưa mua NFT nào.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {ownedNFTs.map(renderCard)}
          </div>
        )}
      </div>

      <div>
        <h3 className="text-xl font-semibold mb-3">🖌️ NFT bạn đã tạo</h3>
        {createdNFTs.length === 0 ? (
          <p className="text-gray-400">Bạn chưa tạo NFT nào.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {createdNFTs.map(renderCard)}
          </div>
        )}
      </div>
    </div>
  );
};

export default TransactionHistoryPage;
