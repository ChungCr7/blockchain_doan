import React from "react";

const WalletInfo = ({ account }) => (
  <p>👛 Địa chỉ ví: <b>{account}</b></p>
);

export default WalletInfo;
